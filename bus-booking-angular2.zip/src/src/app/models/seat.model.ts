export class Seat {
    seatNo:string;
    seatClass:string;
    fare:number;
}